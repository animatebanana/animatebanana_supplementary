AnimateBanana — Colour Pop animation for Paper2Fig_pipe_easy_000000552

Open animation.html in any modern browser. The animation is a self-contained
SVG driven by CSS keyframes; it loops indefinitely and needs no network access.
This figure embeds no bitmap regions.
