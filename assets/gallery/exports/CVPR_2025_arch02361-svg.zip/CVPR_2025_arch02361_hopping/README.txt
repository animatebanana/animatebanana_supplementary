AnimateBanana — Hopping Bbox animation for CVPR_2025_arch02361

Open animation.html in any modern browser. The animation is a self-contained
SVG driven by CSS keyframes; it loops indefinitely and needs no network access.
rasters/ holds the 13 cropped bitmap region(s) the figure embeds.
Keep the folder next to animation.html — it is referenced by relative path.
