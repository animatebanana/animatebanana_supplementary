AnimateBanana — Progressive Reveal animation for arch_arxiv_db_ir_2026_000000718

Open animation.html in any modern browser. The animation is a self-contained
SVG driven by CSS keyframes; it loops indefinitely and needs no network access.
This figure embeds no bitmap regions.
